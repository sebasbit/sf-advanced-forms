<?php

/**
 * AuthorInheritanceConcrete filter form.
 *
 * @package    symfony12
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: AuthorInheritanceConcreteFormFilter.class.php 22748 2009-10-02 23:19:37Z Kris.Wallsmith $
 */
class AuthorInheritanceConcreteFormFilter extends BaseAuthorInheritanceConcreteFormFilter
{
  public function configure()
  {
  }
}
