<?php

require_once dirname(__FILE__).'/../lib/my_articlesGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/my_articlesGeneratorHelper.class.php';

/**
 * my_articles actions.
 *
 * @package    symfony12
 * @subpackage my_articles
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class my_articlesActions extends autoMy_articlesActions
{
}
