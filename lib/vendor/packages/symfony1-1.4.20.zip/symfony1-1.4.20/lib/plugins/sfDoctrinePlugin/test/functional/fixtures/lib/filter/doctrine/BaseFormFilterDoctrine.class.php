<?php

/**
 * Project filter form base class.
 *
 * @package    filters
 *
 * @version    SVN: $Id: BaseFormFilterDoctrine.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
abstract class BaseFormFilterDoctrine extends sfFormFilterDoctrine
{
  public function setup()
  {
  }
}