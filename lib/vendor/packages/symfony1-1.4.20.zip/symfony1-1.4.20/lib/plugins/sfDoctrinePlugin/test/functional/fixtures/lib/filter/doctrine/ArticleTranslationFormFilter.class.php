<?php

/**
 * ArticleTranslation filter form.
 *
 * @package    filters
 * @subpackage ArticleTranslation *
 * @version    SVN: $Id: ArticleTranslationFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ArticleTranslationFormFilter extends BaseArticleTranslationFormFilter
{
  public function configure()
  {
  }
}