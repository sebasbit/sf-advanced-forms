<?php

/**
 * UniqueTest filter form.
 *
 * @package    filters
 * @subpackage UniqueTest *
 * @version    SVN: $Id: UniqueTestFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class UniqueTestFormFilter extends BaseUniqueTestFormFilter
{
  public function configure()
  {
  }
}