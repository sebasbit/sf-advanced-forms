<?php

/**
 * AuthorInheritance form.
 *
 * @package    form
 * @subpackage AuthorInheritance
 * @version    SVN: $Id: AuthorInheritanceForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class AuthorInheritanceForm extends BaseAuthorInheritanceForm
{
  public function configure()
  {
  }
}