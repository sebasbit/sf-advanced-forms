<?php

/**
 * Base project form.
 * 
 * @package    symfony12
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: BaseForm.class.php 18331 2009-05-16 11:13:47Z Kris.Wallsmith $
 */
class BaseForm extends sfFormSymfony
{
}
