<?php

/**
 * BlogAuthor filter form.
 *
 * @package    symfony12
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: BlogAuthorFormFilter.class.php 23668 2009-11-07 12:51:07Z Kris.Wallsmith $
 */
class BlogAuthorFormFilter extends BaseBlogAuthorFormFilter
{
  /**
   * @see AuthorFormFilter
   */
  public function configure()
  {
    parent::configure();
  }
}
